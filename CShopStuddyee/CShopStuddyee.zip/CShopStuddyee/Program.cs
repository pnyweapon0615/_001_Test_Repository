﻿using System;

namespace CShopStuddyee
{
    class Program
    {
        static void Main(string[] args)
        {
            // Comsole.WriteLine = 화면출력 함수
            // Console.ReadLine = 화면에[ 입력해주는 함수는 함수
            // 문장의 끝을 마무리 할땐 ; << 넣어 
            // int(정수)  float(실수)  string(문자열)  bool(참,거짓) -> true, flase
            // 자료형 - 자주쓰는것 int float string bool
            //자료형 이름(변수) = 값; // 초기선언할때 , 대입은 일반적 대입과ㅣ는 다르게 오른쪽에서 왼쪽으로 대입한다
            //비교 연산자 : > < >= <= == !=(크다 작다 크거나같다 작거나같다 같다 다르다)
            //논리연산자 :&& || !(NOT) (== false)
            // 증감 연산자: ++ --(1씩 더함, 1씩 뺌)
            ///ㅅ산술연산자 ; = - * / %
            //조건문 ; (If elseif else),(switch case default)
            /*
            string 나의행동 = "블베깸";
            if (나의행동 == "블베깸"&& 나의행동 => "부티티깸")
            {
                //야노래냗로ㅑㅐㅈ됵8ㅈㄹ8ㅕㄷ89겾89쳐9ㅈ8뎍98ㅈ뎌8겨졎ㄷ98여9ㅕㅈ
            }
            else if(나의행동= "99%"){
                //tlqkf
            }
            else if(나의행동= "아케론")
            {
                //100
                //99
                if (나의행동1 == "ㅑ어ㅐㅑㅈ더애ㅑㅈ더")
                {
                    //100
                }
                else if (나의행동1 == "려차")
                {
                    //99
                }
            }
            else
            {
                //접음
            }
            switch (나의행동)
            {
                case "블베깸":
                case "부티티깸";
                    //sdefjweoifjweoifjweifjewjfiewjtvurvt309vir0n-nirn9i0ivwnponsexwiuoewrvnwerpipdooonfuinck
                    break;
                case "99%":
                    //tq
                    break;
                case "아케론":
                    switch (나의행동1)
                    {
                        case "ㅑ어ㅐㅑㅈ더애ㅑㅈ더":
                            //qwdkpqwdkp
                            break;
                        case "려차":
                            //ㄷㄷㄹㄹ
                            break;
                        default:
                            //dewwdedew
                            break;
                    }
            switch (시간)
                    break;
            }
            {
                case >= 10:
                    break;
            }

            
            // if(변수1 (비교연산자) 변수 2)
            //{
            //  문장;
            //}

            */
            int vat = int.Parse(Console.ReadLine());
            if (gg <= -20)
            {
                Console.WriteLine("-20이하");
            }
            else if (gg >= 50)
            {
                Console.WriteLine("50이상");
            }
            
            if (gg > 0)
            {
                Console.WriteLine("양수");
            }
            else if (gg < 0)
            {
                Console.WriteLine("음수");
            }

            string s = Console.ReadLine();
            Console.WriteLine();
            switch (s)
            {
                case "int":
                    Console.WriteLine("정수");
                    break;
                case "float":
                    Console.WriteLine("실수");
                    break;
                case "string":
                    Console.WriteLine("문자열");
                    break;
                case "bool":
                    Console.WriteLine("참거짓");
                    break;
            }




            int num = int.Parse(Console.ReadLine());
                Console.WriteLine(n);
            if (num <= 10)
            {
                Console.WriteLine("잼민이");
            }
            else if (num <= 20)
            {
                Console.WriteLine("청소년");
            }
            else if (num <= 35)
            {
                Console.WriteLine("청년");
            }
            else if (num <= 60)
            {
                Console.WriteLine("청소년");
            }
            else
            {
                Console.WriteLine("고령");
            }

            string s = Console.ReadLine();
                Console.WriteLine();
            switch (s)
            {
                case "int":
                    Console.WriteLine("정수");
                    break;
                case "float":
                    Console.WriteLine("실수");
                    break;
                case "string":
                    Console.WriteLine("문자열");
                    break;
                case "bool":
                    Console.WriteLine("참거짓");
                    break;
            }
            string str = Console.ReadLine();
                Console.WriteLine(str);
                if (str == "수")
                {
                    Console.WriteLine("수 95이상");
                }
                else if (str == "우")
                {
                    Console.WriteLine("우 80이상");
                }
                else if (str == "우")
                {
                    Console.WriteLine("미 60이상");
                }
                else if (str == "우")
                {
                    Console.WriteLine("양 40이상");
                }
                else if (str == "우")
                {
                    Console.WriteLine("가 40이하");
                }








            //switch (A값)
            //{
            //  case B값;
            //      문장;
            //     break;
            //{
            int a = 100;
            a = 2 + 3 + 5 + 7;
            0.33333333333 = 1 / 3;
            1 = 1 % 3;
            Console.WriteLine("ㅎㅇ");
            Console.WriteLine("ㄹㅇㅋㅋ");
            Console.ReadLine();
            Console.WriteLine();
        }
    }
}
